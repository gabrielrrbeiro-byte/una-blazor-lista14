<img width="1600" height="740" alt="image" src="https://github.com/user-attachments/assets/d546619f-61a7-4a30-8388-7f51a8145c5e" />
